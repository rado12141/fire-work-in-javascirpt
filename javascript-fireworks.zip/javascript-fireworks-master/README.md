<h1 align="center">
    <img src="fireworks.gif" alt="Fireworks created in JavaScript" />
</h1>
<h4 align="center">You can read the written tutorial about the implementation on <strong><a href="https://www.webtips.dev/fireworks-in-javascript">webtips.dev</a></strong> ✨</h4>
